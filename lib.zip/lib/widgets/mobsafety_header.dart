import 'package:flutter/material.dart';
import 'package:moby_safe_estagio/pages/menu_principal_page.dart';
import 'package:moby_safe_estagio/pages/relatorios_page.dart';
import 'package:moby_safe_estagio/pages/dados_conta_page.dart';
import 'package:moby_safe_estagio/pages/quem_somos_page.dart';
import 'package:moby_safe_estagio/pages/login_page.dart';

class MobSafetyAppBar {
  static PreferredSizeWidget build(BuildContext context) {
    return AppBar(
      titleSpacing: 0,
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'MobSafety',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 18,
            ),
          ),
          Text(
            'Inspeção de Segurança Viária',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
      actions: [
        PopupMenuButton<_MenuAction>(
          icon: const Icon(Icons.more_vert),
          onSelected: (value) {
            switch (value) {
              case _MenuAction.menuPrincipal:
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const MenuPrincipalPage(),
                  ),
                  (route) => false,
                );
                break;

              case _MenuAction.relatorios:
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const RelatoriosPage(),
                  ),
                );
                break;

              case _MenuAction.dadosConta:
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const DadosContaPage(),
                  ),
                );
                break;

              case _MenuAction.quemSomos:
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const QuemSomosPage(),
                  ),
                );
                break;

              case _MenuAction.sair:
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const LoginPage(),
                  ),
                  (route) => false,
                );
                break;
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: _MenuAction.menuPrincipal,
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.home_rounded),
                title: Text('Menu principal'),
              ),
            ),
            const PopupMenuItem(
              value: _MenuAction.relatorios,
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.insert_drive_file_rounded),
                title: Text('Relatórios'),
              ),
            ),
            const PopupMenuItem(
              value: _MenuAction.dadosConta,
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.account_circle_rounded),
                title: Text('Dados da conta'),
              ),
            ),
            const PopupMenuItem(
              value: _MenuAction.quemSomos,
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.info_rounded),
                title: Text('Quem somos'),
              ),
            ),
            const PopupMenuDivider(),
            const PopupMenuItem(
              value: _MenuAction.sair,
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                  Icons.logout_rounded,
                  color: Colors.red,
                ),
                title: Text(
                  'Sair',
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

enum _MenuAction {
  menuPrincipal,
  relatorios,
  dadosConta,
  quemSomos,
  sair,
}
