import 'package:flutter/material.dart';
import 'package:moby_safe_estagio/pages/login_page.dart';

void main() {
  runApp(const MobSafetyApp());
}

class MobSafetyApp extends StatelessWidget {
  const MobSafetyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MobSafety',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.blueGrey,
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}
